Andrew Taylor
atayl136
07/10/23

This was created in PyCharm 2022.3.2 with Python 3.8 in a generic environment. Because other students reported difficulties with the venv I kept it simple.
This should run in your environment no problem, or any basic environment really, the only libraries I used were numpy, random and argmax I think.

I couldn't get the utility_player_tests.py working until late Monday night, so I ran out of time to fix my utility player. :(

