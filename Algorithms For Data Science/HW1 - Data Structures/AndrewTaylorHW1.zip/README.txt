
Created for the en685621 kernel and environment, using Jupyter notebooks.

packages used:
pandas


thank you