Written in Python 3.10.4
Using Anaconda 3 and PyCharm 2022.3.2

The input file should be in the same folder as the project, 
not in the project folder. It needs to be taken out.

python AndrewTaylorLab1 "Required Input.txt"

or any other named file as the first positional argument will run.