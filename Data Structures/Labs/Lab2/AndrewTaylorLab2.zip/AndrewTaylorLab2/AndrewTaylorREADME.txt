Written in Python 3.10.4
Using Anaconda 3 and PyCharm 2022.3.2

The input file should be in the same folder as the project, 
not in the project folder itself. It needs to be out of the Lab2 folder.

python Lab2 "Required Input.txt"
python Lab2 "Test Cases.txt"

from the AndrewTaylorLab2 directory
or any other named file as the first positional argument will run.