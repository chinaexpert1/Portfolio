Written in Python 3.10.4
Using Anaconda 3 and PyCharm 2022.3.2

The input file should be in the same folder as the project, 
not in the project folder. I left them there.

python Lab3 

runs the file. I commented out the code for named files but it is there.

Output is summarized in one file, called "output.txt"