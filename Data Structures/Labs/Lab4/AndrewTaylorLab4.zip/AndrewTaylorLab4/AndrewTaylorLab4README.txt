Written in Python 3.10.4
Using Anaconda 3 and PyCharm 2022.3.2

The input files should be in the folders input_files and size_50_files, which are located in the same directory as the .py files...
I duplicated the size 50 files so they could easily be processed for individual reports.
Both .py files work, and you can run them directly, right where they are, without any argument.


All sorts output is summarized in one file, and the individual output files for size 50 sorts follow.